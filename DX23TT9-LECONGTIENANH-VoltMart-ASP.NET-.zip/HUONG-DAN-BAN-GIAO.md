# Hướng dẫn bàn giao đồ án VoltMart

## Trạng thái hiện tại

Đồ án website bán linh kiện điện tử VoltMart đã được dựng theo ASP.NET Core MVC:

- Front-end bán hàng theo giao diện mẫu Điện Tử Pro.
- Admin dashboard dùng AdminLTE.
- Entity Framework Core, ASP.NET Identity, phân quyền Admin/Customer.
- Giỏ hàng, thanh toán, mã giảm giá, wishlist, lịch sử/theo dõi đơn hàng.
- CRUD danh mục, thương hiệu, nhà cung cấp, sản phẩm, đơn hàng, tin tức, banner, khuyến mãi, liên hệ.
- Migration `InitialCreate` và script SQL Server đã có sẵn.
- Build kiểm tra lần cuối: đạt, 0 lỗi, 0 cảnh báo.

## File quan trọng

- Mã nguồn: `src/VoltMart`
- Solution: `VoltMart.sln`
- SQL Server script: `setup/VoltMartDb.sql`
- Báo cáo kiểm thử: `TEST-REPORT.md`
- Danh sách chức năng nghiệm thu: `thesis/html/DANH-SACH-CHUC-NANG.md`
- Gói nộp bài đầy đủ: `outputs/VoltMart-ASP.NET-Core-MVC-Full.zip`

## Chạy nhanh trên máy hiện tại

```powershell
$env:DOTNET_CLI_HOME=(Resolve-Path 'work').Path
$env:NUGET_PACKAGES=(Join-Path (Resolve-Path 'work').Path '.nuget\packages')
$env:DOTNET_ROLL_FORWARD='Major'
$env:ASPNETCORE_ENVIRONMENT='Development'
dotnet run --project src\VoltMart --urls http://127.0.0.1:5086
```

Mở trình duyệt:

```text
http://127.0.0.1:5086
```

Tài khoản quản trị:

```text
Email: admin@voltmart.vn
Mật khẩu: Admin@123
```

## Chạy trên máy có Visual Studio / SQL Server

Yêu cầu:

- Visual Studio 2022
- .NET 8 SDK
- SQL Server hoặc SQL Server LocalDB

Lệnh:

```powershell
dotnet tool restore
dotnet restore VoltMart.sln
dotnet ef database update --project src/VoltMart
dotnet run --project src/VoltMart
```

Nếu muốn tạo database bằng script SQL:

```text
setup/VoltMartDb.sql
```

## Lưu ý khi đổi tài khoản Codex

Nếu đổi tài khoản nhưng vẫn dùng cùng thư mục này, chỉ cần mở lại workspace:

```text
C:\Users\PC\Documents\Codex\2026-06-22\hay
```

Sau đó gửi yêu cầu kiểu:

```text
Tiếp tục đồ án VoltMart trong workspace này. Đọc HUONG-DAN-BAN-GIAO.md, README.md và TEST-REPORT.md trước.
```

Như vậy tài khoản mới vẫn có đủ ngữ cảnh để tiếp tục.

## Việc nên làm tiếp nếu muốn hoàn thiện hồ sơ nộp

- Điền họ tên, MSSV, lớp trong README và báo cáo.
- Nghiệm thu lại trên SQL Server/LocalDB của máy nộp bài.
- Tạo file báo cáo `.docx`.
- Tạo slide bảo vệ `.pptx`.
- Quay video demo các chức năng chính.
