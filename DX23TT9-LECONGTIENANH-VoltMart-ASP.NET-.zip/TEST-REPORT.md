# Báo cáo kiểm thử VoltMart

Ngày kiểm thử tích hợp: 22/06/2026

## Kết quả build và cơ sở dữ liệu

| Hạng mục | Kết quả |
|---|---|
| `dotnet restore` | Đạt |
| `dotnet build` | Đạt - 0 lỗi, 0 cảnh báo |
| Migration `InitialCreate` | Đạt |
| Script SQL Server idempotent | Đạt |
| SQLite development database | Đạt |
| Seed role, admin và dữ liệu mẫu | Đạt |

## Ca kiểm thử chức năng

| Mã | Ca kiểm thử | Kết quả |
|---|---|---|
| TC01 | Khởi động ứng dụng và tạo database | Đạt |
| TC02 | Seed 10 danh mục, 12 sản phẩm, banner và tin tức | Đạt |
| TC03 | Trang chủ hiển thị header, sidebar, banner, sản phẩm và footer | Đạt |
| TC04 | Tìm kiếm `ESP32` | Đạt |
| TC05 | Sắp xếp giá giảm dần | Đạt |
| TC06 | Thêm Relay vào giỏ bằng AJAX | Đạt - badge tăng thành 1 |
| TC07 | Mở giỏ và chuyển sang checkout | Đạt |
| TC08 | Áp mã `WELCOME10` | Đạt |
| TC09 | Tạo đơn hàng và trừ tồn kho trong transaction | Đạt |
| TC10 | Trang xác nhận trả mã đơn | Đạt - `VM260622235509132` |
| TC11 | Đăng nhập `admin@voltmart.vn` | Đạt |
| TC12 | Phân quyền chuyển đến `/Admin` | Đạt |
| TC13 | Dashboard hiển thị doanh thu, đơn, khách và sản phẩm | Đạt |
| TC14 | Dashboard sau đơn thử: 48.000đ, 1 đơn, 1 khách, 12 sản phẩm | Đạt |
| TC15 | Kiểm tra console trình duyệt | Đạt - 0 lỗi |
| TC16 | JavaScript syntax | Đạt |

## Cấu hình kiểm thử

- SDK biên dịch: .NET SDK 10.0.301.
- Target framework: .NET 8.
- Runtime sử dụng trong môi trường kiểm thử: roll-forward sang .NET 10.
- Database kiểm thử: SQLite.
- Database triển khai yêu cầu đồ án: SQL Server.

## Lưu ý

Máy hiện chưa cài SQL Server Database Engine/LocalDB, vì vậy phần tích hợp được
chạy bằng SQLite. Migration và script SQL Server đã được tạo thành công từ cùng
`ApplicationDbContext`. Trên máy có Visual Studio 2022 + LocalDB, chạy
`dotnet ef database update` để nghiệm thu SQL Server.
