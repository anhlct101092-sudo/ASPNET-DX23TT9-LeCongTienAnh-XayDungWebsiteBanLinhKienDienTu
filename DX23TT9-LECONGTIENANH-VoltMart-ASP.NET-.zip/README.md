# VOLTMART - Đồ án website bán linh kiện điện tử

VoltMart là website thương mại điện tử được xây dựng bằng **ASP.NET Core MVC .NET 8**, Entity Framework Core, SQL Server và ASP.NET Identity. Giao diện khách hàng phát triển theo mẫu cửa hàng linh kiện điện tử chuyên nghiệp; khu quản trị sử dụng AdminLTE và Chart.js.

## Công nghệ

- ASP.NET Core MVC 8
- Entity Framework Core 8 + SQL Server/LocalDB
- SQLite cho chế độ phát triển cục bộ khi máy chưa cài SQL Server
- ASP.NET Core Identity, phân quyền `Admin` và `Customer`
- Repository, Service và Dependency Injection
- Bootstrap 5, Bootstrap Icons
- AdminLTE 4, Chart.js
- jQuery và AJAX
- Session cart, transaction khi đặt hàng

## Chức năng khách hàng

- Trang chủ: sidebar danh mục, banner, sản phẩm nổi bật, sản phẩm mới và tin tức.
- Danh sách sản phẩm có phân trang.
- Tìm kiếm theo tên, SKU, thương hiệu và danh mục.
- Lọc danh mục, thương hiệu, khoảng giá; sắp xếp giá/bán chạy/mới nhất.
- Chi tiết sản phẩm, thư viện ảnh, thông số và sản phẩm liên quan.
- Giỏ hàng dùng Session; AJAX thêm sản phẩm và kiểm tra tồn kho.
- Checkout, miễn phí vận chuyển từ 500.000đ, mã giảm giá.
- Đăng ký, đăng nhập, đăng xuất bằng ASP.NET Identity.
- Vai trò khách hàng và quản trị viên.
- Wishlist, lịch sử đơn hàng và theo dõi tiến độ đơn.
- Tin tức, hướng dẫn mua hàng và form liên hệ.
- Responsive cho máy tính, máy tính bảng và điện thoại.

## Chức năng quản trị

- Dashboard doanh thu 6 tháng, top sản phẩm, đơn gần đây và cảnh báo tồn kho.
- CRUD sản phẩm, upload ảnh đại diện và nhiều ảnh thư viện.
- Quản lý danh mục, thương hiệu và nhà cung cấp.
- Quản lý đơn hàng, cập nhật trạng thái xử lý/thanh toán.
- Quản lý khách hàng.
- Quản lý tin tức, banner, mã khuyến mãi và liên hệ.
- Tìm kiếm, lọc và phân trang.
- Audit log cho thao tác quản trị quan trọng.
- Ràng buộc dữ liệu và bảo toàn sản phẩm đã phát sinh đơn hàng.

## Mô hình dữ liệu

Hệ thống gồm 16 bảng nghiệp vụ:

`Category`, `Brand`, `Supplier`, `Product`, `ProductImage`, `Customer`, `Employee`, `Order`, `OrderDetail`, `Review`, `Promotion`, `News`, `Banner`, `Contact`, `Wishlist`, `AuditLog`.

Ngoài ra có các bảng chuẩn của ASP.NET Identity như `AspNetUsers`, `AspNetRoles`, `AspNetUserRoles`.

## Cài đặt

Yêu cầu:

- .NET 8 SDK
- SQL Server 2019+ hoặc SQL Server LocalDB

Các bước:

```powershell
dotnet tool restore
dotnet restore VoltMart.sln
dotnet ef migrations add InitialCreate --project src/VoltMart
dotnet ef database update --project src/VoltMart
dotnet run --project src/VoltMart
```

Khi chạy bằng profile `Development`, ứng dụng tự dùng SQLite tại
`src/VoltMart/App_Data/voltmart-dev.db` để có thể khởi động ngay. Cấu hình mặc
định `Production` vẫn sử dụng SQL Server đúng yêu cầu đồ án.

Hoặc:

```powershell
cd setup
.\init-database.ps1
dotnet run --project ..\src\VoltMart
```

Mặc định ứng dụng dùng LocalDB:

```text
Server=(localdb)\mssqllocaldb;Database=VoltMartDb;Trusted_Connection=True
```

Muốn dùng SQL Server thường, sửa `ConnectionStrings:DefaultConnection` trong `src/VoltMart/appsettings.json`.

Script SQL Server sinh từ migration có sẵn tại `setup/VoltMartDb.sql`.

## Trạng thái xác minh

- `dotnet restore`: thành công.
- `dotnet build`: thành công, **0 lỗi và 0 cảnh báo**.
- Migration `InitialCreate`: đã tạo.
- Script SQL Server idempotent: đã tạo.
- SQLite development database: đã tạo và seed thành công.
- Đã kiểm thử trực tiếp trang chủ, tìm kiếm/lọc, thêm giỏ AJAX, checkout,
  mã giảm giá, tạo đơn, đăng nhập Admin và dashboard.

## Tài khoản seed

```text
Admin:    admin@voltmart.vn
Password: Admin@123
```

Khách hàng tự đăng ký tại `/Account/Register`.

## Dữ liệu mẫu

Ứng dụng tự seed:

- 10 danh mục.
- 6 thương hiệu.
- 2 nhà cung cấp.
- 12 sản phẩm.
- Banner, tin tức và mã giảm giá `WELCOME10`.

## Cấu trúc mã nguồn

```text
src/VoltMart/
├── Areas/Admin/             Khu quản trị và các view AdminLTE
├── Controllers/             Controller phía khách hàng
├── Data/                    DbContext và dữ liệu seed
├── Models/                  Entity và ViewModel
├── Services/                Repository, Product, Cart, Order, File
├── Views/                   Razor Views phía khách hàng
├── wwwroot/                 CSS, JavaScript, SVG và upload
├── Program.cs
└── appsettings.json
```

## Lưu ý trước khi nộp

- Thay thông tin sinh viên trong tài liệu đồ án.
- Không commit mật khẩu hoặc connection string máy chủ thật.
- Tạo migration và chạy build trên máy có .NET 8 SDK.
- Đổi mật khẩu quản trị seed khi triển khai công khai.
- Commit tiến độ tối thiểu mỗi tuần theo quy định môn học.

## Tác giả

- Sinh viên: `[Điền họ tên]`
- MSSV: `[Điền mã số sinh viên]`
- Lớp: `[Điền lớp]`
- Email: `[Điền email]`
- Điện thoại: `[Điền số điện thoại]`
