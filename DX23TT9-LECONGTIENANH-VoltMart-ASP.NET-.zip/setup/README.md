# Cài đặt VoltMart

## 1. Chuẩn bị

- Visual Studio 2022 có workload **ASP.NET and web development**, hoặc .NET 8 SDK.
- SQL Server Express/Developer hoặc SQL Server LocalDB.

## 2. Tạo cơ sở dữ liệu

```powershell
dotnet tool restore
dotnet restore ..\VoltMart.sln
.\init-database.ps1
```

Script sẽ tạo migration `InitialCreate` nếu chưa có và chạy `database update`.

## 3. Chạy ứng dụng

```powershell
dotnet run --project ..\src\VoltMart
```

Profile phát triển dùng SQLite nên có thể chạy ngay cả khi chưa cài SQL Server.
Muốn chạy đúng SQL Server, đặt `ASPNETCORE_ENVIRONMENT=Production`, bảo đảm
connection string hợp lệ và chạy migration.

## 4. Đăng nhập quản trị

- Email: `admin@voltmart.vn`
- Mật khẩu: `Admin@123`

## 5. Cấu hình SQL Server khác

Sửa `DefaultConnection`:

```json
"DefaultConnection": "Server=.;Database=VoltMartDb;Trusted_Connection=True;TrustServerCertificate=True"
```

## 6. Khôi phục dữ liệu mẫu

Xóa database `VoltMartDb`, chạy lại migration và khởi động ứng dụng. Dữ liệu mẫu được seed tự động.

## 7. Script SQL Server

Có thể chạy file `VoltMartDb.sql` trong SQL Server Management Studio. Đây là
script idempotent được sinh trực tiếp từ migration `InitialCreate`.
