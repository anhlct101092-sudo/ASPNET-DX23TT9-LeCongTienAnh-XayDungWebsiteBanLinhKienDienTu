IF DB_ID(N'VoltMartDb') IS NULL
BEGIN
    CREATE DATABASE VoltMartDb;
END
GO

USE VoltMartDb;
GO

-- Cấu trúc bảng được quản lý bằng Entity Framework Core Migration.
-- Sau khi chạy file này, thực hiện:
-- dotnet ef database update --project ..\src\VoltMart
