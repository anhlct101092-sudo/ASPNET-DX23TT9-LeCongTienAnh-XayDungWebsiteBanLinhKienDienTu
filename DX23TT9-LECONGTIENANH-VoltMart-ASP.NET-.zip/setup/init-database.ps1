param(
    [string]$Project = "..\src\VoltMart\VoltMart.csproj",
    [string]$MigrationName = "InitialCreate"
)

$ErrorActionPreference = "Stop"

dotnet tool restore

$migrations = Get-ChildItem -Path "..\src\VoltMart\Migrations" -Filter "*.cs" -ErrorAction SilentlyContinue
if (-not $migrations) {
    dotnet ef migrations add $MigrationName --project $Project
}

dotnet ef database update --project $Project
Write-Host "VoltMart database is ready." -ForegroundColor Green
