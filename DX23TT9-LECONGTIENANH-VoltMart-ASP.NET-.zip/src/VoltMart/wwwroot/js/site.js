$(function(){
  const token=()=>$('input[name="__RequestVerificationToken"]').first().val();
  $('.add-cart-form').on('submit',function(e){
    e.preventDefault();const form=$(this);
    $.ajax({url:form.attr('action'),method:'POST',data:form.serialize(),headers:{'X-Requested-With':'XMLHttpRequest'}})
      .done(r=>{if(r.success){$('#cartCount').text(r.count);$('#cartSubtotal').text(Number(r.subtotal).toLocaleString('vi-VN')+'đ')}showToast(r.message,r.success)})
      .fail(()=>showToast('Không thể thêm sản phẩm vào giỏ.',false));
  });
  $('.wishlist-form').on('submit',function(e){
    if(!$('body').data('authenticated')){
      e.preventDefault();
      location.href='/Account/Login?returnUrl='+encodeURIComponent(location.pathname+location.search);
      return;
    }
    e.preventDefault();const form=$(this);
    $.ajax({url:form.attr('action'),method:'POST',data:form.serialize(),headers:{'X-Requested-With':'XMLHttpRequest'}})
      .done(r=>{const i=form.find('i');i.toggleClass('bi-heart',!r.added).toggleClass('bi-heart-fill',r.added);showToast(r.added?'Đã thêm vào yêu thích.':'Đã bỏ khỏi yêu thích.',true)})
      .fail(x=>{if(x.status===401)location.href='/Account/Login?returnUrl='+encodeURIComponent(location.pathname)});
  });
  let searchTimer;
  $('#globalSearch').on('input',function(){
    clearTimeout(searchTimer);const q=this.value.trim(),box=$('#searchSuggestions');
    if(q.length<2){box.addClass('d-none').empty();return}
    searchTimer=setTimeout(()=>$.getJSON('/Products/Suggestions',{q}).done(items=>{
      if(!items.length){box.addClass('d-none');return}
      box.html(items.map(x=>`<a href="/san-pham/${x.slug}"><img src="${x.thumbnailUrl||'/images/products/chip.svg'}"><span><b>${escapeHtml(x.name)}</b><small>${Number(x.price).toLocaleString('vi-VN')}đ</small></span></a>`).join('')).removeClass('d-none');
    }),250);
  });
  $(document).on('click',e=>{if(!$(e.target).closest('.header-search').length)$('#searchSuggestions').addClass('d-none')});
  $('[data-image]').on('click',function(){$('[data-image]').removeClass('active');$(this).addClass('active');$('#mainProductImage').attr('src',$(this).data('image'))});
  $('[data-qty]').on('click',function(){const input=$(this).siblings('input'),next=Math.max(1,Math.min(Number(input.attr('max')),Number(input.val())+Number($(this).data('qty'))));input.val(next)});
  function showToast(message,success){const t=$(`<div class="toast-message ${success?'success':'error'}">${escapeHtml(message)}</div>`);$('body').append(t);setTimeout(()=>t.remove(),4200)}
  function escapeHtml(s){return $('<div>').text(s||'').html()}
});
