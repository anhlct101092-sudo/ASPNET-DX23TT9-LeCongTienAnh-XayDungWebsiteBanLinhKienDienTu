using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using VoltMart.Models;

namespace VoltMart.Data;

public static class DbInitializer
{
    public static async Task InitializeAsync(IServiceProvider services)
    {
        var context = services.GetRequiredService<ApplicationDbContext>();
        if (context.Database.IsSqlite())
            await context.Database.EnsureCreatedAsync();
        else if (context.Database.GetMigrations().Any())
            await context.Database.MigrateAsync();
        else
            await context.Database.EnsureCreatedAsync();

        var roleManager = services.GetRequiredService<RoleManager<IdentityRole>>();
        var userManager = services.GetRequiredService<UserManager<ApplicationUser>>();
        foreach (var role in new[] { "Admin", "Customer" })
            if (!await roleManager.RoleExistsAsync(role))
                await roleManager.CreateAsync(new IdentityRole(role));

        const string adminEmail = "admin@voltmart.vn";
        var admin = await userManager.FindByEmailAsync(adminEmail);
        if (admin is null)
        {
            admin = new ApplicationUser
            {
                UserName = adminEmail, Email = adminEmail, EmailConfirmed = true,
                FullName = "Quản trị VoltMart", PhoneNumber = "0901234567"
            };
            var result = await userManager.CreateAsync(admin, "Admin@123");
            if (result.Succeeded) await userManager.AddToRoleAsync(admin, "Admin");
        }

        if (await context.Products.AnyAsync()) return;

        var categories = new[]
        {
            new Category { Name="IC - Vi điều khiển", Slug="ic-vi-dieu-khien", Icon="bi-cpu", DisplayOrder=1 },
            new Category { Name="Linh kiện thụ động", Slug="linh-kien-thu-dong", Icon="bi-activity", DisplayOrder=2 },
            new Category { Name="Linh kiện bán dẫn", Slug="linh-kien-ban-dan", Icon="bi-diagram-3", DisplayOrder=3 },
            new Category { Name="Module - Board mạch", Slug="module-board-mach", Icon="bi-motherboard", DisplayOrder=4 },
            new Category { Name="Cảm biến", Slug="cam-bien", Icon="bi-broadcast-pin", DisplayOrder=5 },
            new Category { Name="Nguồn điện", Slug="nguon-dien", Icon="bi-lightning-charge", DisplayOrder=6 },
            new Category { Name="Hiển thị", Slug="hien-thi", Icon="bi-display", DisplayOrder=7 },
            new Category { Name="Kết nối", Slug="ket-noi", Icon="bi-usb-symbol", DisplayOrder=8 },
            new Category { Name="Công cụ - Thiết bị", Slug="cong-cu-thiet-bi", Icon="bi-tools", DisplayOrder=9 },
            new Category { Name="Phụ kiện khác", Slug="phu-kien-khac", Icon="bi-box-seam", DisplayOrder=10 }
        };
        var brands = new[]
        {
            new Brand { Name="STMicroelectronics", Slug="stmicroelectronics" },
            new Brand { Name="Arduino", Slug="arduino" },
            new Brand { Name="Espressif", Slug="espressif" },
            new Brand { Name="Texas Instruments", Slug="texas-instruments" },
            new Brand { Name="Songle", Slug="songle" },
            new Brand { Name="Aosong", Slug="aosong" }
        };
        var suppliers = new[]
        {
            new Supplier { Name="Công ty Linh Kiện Việt", Phone="02873001234", Email="sales@linhkienviet.vn", Address="TP. Hồ Chí Minh" },
            new Supplier { Name="Maker Supply", Phone="02923778899", Email="hello@makersupply.vn", Address="Cần Thơ" }
        };
        await context.AddRangeAsync(categories);
        await context.AddRangeAsync(brands);
        await context.AddRangeAsync(suppliers);
        await context.SaveChangesAsync();

        var products = new[]
        {
            Product("STM32F103C8T6","stm32f103c8t6","STM32F103C8T6",22500,250,"/images/products/chip.svg",categories[0],brands[0],suppliers[0],10,true),
            Product("ARD-UNO-R3","arduino-uno-r3","Arduino UNO R3",165000,85,"/images/products/arduino.svg",categories[3],brands[1],suppliers[0],0,true),
            Product("LCD-16X2-I2C","lcd-16x2-i2c","LCD 16x2 I2C",45000,120,"/images/products/lcd.svg",categories[6],brands[3],suppliers[1],5,true),
            Product("RELAY-5V-1","relay-5v-1-kenh","Relay 5V 1 Kênh",18000,190,"/images/products/relay.svg",categories[3],brands[4],suppliers[1],0,true),
            Product("ESP32-DEV-V1","esp32-devkit-v1","ESP32 DevKit V1",115000,75,"/images/products/esp32.svg",categories[3],brands[2],suppliers[0],8,true),
            Product("DHT22-MOD","cam-bien-dht22","Cảm biến nhiệt độ độ ẩm DHT22",38000,98,"/images/products/dht22.svg",categories[4],brands[5],suppliers[0],0,true),
            Product("NE555-DIP8","ic-dinh-thoi-ne555","IC định thời NE555 DIP-8",12000,340,"/images/products/chip.svg",categories[0],brands[3],suppliers[0],0,false),
            Product("RES-KIT-600","bo-dien-tro-600","Bộ điện trở 30 giá trị 600 chiếc",119000,42,"/images/products/resistor.svg",categories[1],brands[3],suppliers[1],12,false),
            Product("L298N-MOD","module-dieu-khien-l298n","Module điều khiển động cơ L298N",59000,68,"/images/products/relay.svg",categories[3],brands[0],suppliers[1],0,false),
            Product("HC-SR04","cam-bien-sieu-am-hcsr04","Cảm biến siêu âm HC-SR04",32000,105,"/images/products/sensor.svg",categories[4],brands[5],suppliers[0],0,false),
            Product("PWR-12V-5A","nguon-to-ong-12v-5a","Nguồn tổ ong 12V 5A",185000,23,"/images/products/power.svg",categories[5],brands[3],suppliers[0],6,false),
            Product("SOLDER-936","tram-han-936","Trạm hàn điều chỉnh nhiệt 936",649000,14,"/images/products/tool.svg",categories[8],brands[3],suppliers[1],0,false)
        };
        await context.Products.AddRangeAsync(products);

        await context.Banners.AddRangeAsync(
            new Banner { Title="Linh kiện điện tử chính hãng - chất lượng", Subtitle="Đa dạng sản phẩm - Giá tốt mỗi ngày - Hỗ trợ kỹ thuật tận tâm", ImageUrl="/images/hero-circuit.svg", LinkUrl="/Products", DisplayOrder=1 },
            new Banner { Title="Bắt đầu dự án IoT cùng ESP32", Subtitle="Wi-Fi, Bluetooth và hệ sinh thái module đa dạng", ImageUrl="/images/hero-circuit.svg", LinkUrl="/san-pham/esp32-devkit-v1", DisplayOrder=2 }
        );
        await context.News.AddRangeAsync(
            new News { Title="Hướng dẫn chọn nguồn cho mạch điện tử", Slug="huong-dan-chon-nguon", Summary="Cách tính điện áp, dòng điện và công suất nguồn phù hợp.", Content="<p>Nguồn điện ổn định là nền tảng của một mạch hoạt động tin cậy...</p>", ThumbnailUrl="/images/news/power-guide.svg", PublishedAt=DateTime.Now.AddDays(-2) },
            new News { Title="ESP32 hay Arduino Uno cho người mới?", Slug="esp32-hay-arduino-uno", Summary="So sánh nhanh hai board phát triển phổ biến nhất.", Content="<p>Arduino Uno dễ bắt đầu, trong khi ESP32 mạnh hơn và có kết nối không dây...</p>", ThumbnailUrl="/images/news/board-guide.svg", PublishedAt=DateTime.Now.AddDays(-5) },
            new News { Title="10 lỗi thường gặp khi hàn linh kiện", Slug="loi-thuong-gap-khi-han", Summary="Những lỗi nhỏ khiến mối hàn kém bền và cách khắc phục.", Content="<p>Kiểm soát nhiệt độ và vệ sinh đầu mũi hàn giúp tăng chất lượng...</p>", ThumbnailUrl="/images/news/solder-guide.svg", PublishedAt=DateTime.Now.AddDays(-8) }
        );
        await context.Promotions.AddAsync(new Promotion
        {
            Code="WELCOME10", Name="Giảm 10% cho đơn đầu tiên", Type=PromotionType.Percent,
            Value=10, MinimumOrder=200000, MaximumDiscount=100000, UsageLimit=100,
            StartsAt=DateTime.Today.AddDays(-30), EndsAt=DateTime.Today.AddMonths(6)
        });
        await context.SaveChangesAsync();
    }

    private static Product Product(string sku, string slug, string name, decimal price, int stock,
        string image, Category category, Brand brand, Supplier supplier, int discount, bool featured) =>
        new()
        {
            Sku=sku, Slug=slug, Name=name, Price=price,
            ComparePrice=discount > 0 ? Math.Round((price/(1-discount/100m))/1000m)*1000m : null,
            CostPrice=price*.7m, StockQuantity=stock, ThumbnailUrl=image, Category=category, Brand=brand, Supplier=supplier,
            ShortDescription=$"{name} chính hãng, kiểm tra kỹ trước khi giao.", Description=$"<h3>{name}</h3><p>Sản phẩm phù hợp cho học tập, nghiên cứu và các dự án điện tử thực tế.</p>",
            Specifications="Điện áp: Theo datasheet\nXuất xứ: Chính hãng\nBảo hành: 7 ngày", DiscountPercent=discount,
            IsFeatured=featured, IsNew=!featured, SoldCount=Random.Shared.Next(5,90)
        };
}
