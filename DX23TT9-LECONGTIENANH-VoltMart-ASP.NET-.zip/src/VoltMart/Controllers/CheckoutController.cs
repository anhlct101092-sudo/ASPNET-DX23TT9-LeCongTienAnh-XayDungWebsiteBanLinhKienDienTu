using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using VoltMart.Models;
using VoltMart.Services;

namespace VoltMart.Controllers;

public class CheckoutController(ICartService cartService, IOrderService orderService,
    UserManager<ApplicationUser> userManager) : Controller
{
    [HttpGet]
    public async Task<IActionResult> Index()
    {
        var cart = await cartService.GetAsync();
        if (cart.Items.Count == 0) return RedirectToAction("Index", "Cart");
        var user = await userManager.GetUserAsync(User);
        return View(new CheckoutViewModel
        {
            Cart=cart, ReceiverName=user?.FullName ?? "", ReceiverPhone=user?.PhoneNumber ?? "",
            ShippingAddress=user?.Address ?? "", ShippingFee=cart.Subtotal >= 500000 ? 0 : 30000
        });
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Index(CheckoutViewModel model)
    {
        model.Cart = await cartService.GetAsync();
        model.ShippingFee = model.Cart.Subtotal >= 500000 ? 0 : 30000;
        if (!ModelState.IsValid) return View(model);
        var result = await orderService.CreateAsync(model, await userManager.GetUserAsync(User));
        if (result.Order is null)
        {
            ModelState.AddModelError("", result.Error!);
            return View(model);
        }
        return RedirectToAction(nameof(Success), new { code = result.Order.OrderCode });
    }

    public IActionResult Success(string code) => View(model: code);
}
