using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using VoltMart.Data;
using VoltMart.Models;

namespace VoltMart.Controllers;

public class AccountController(UserManager<ApplicationUser> userManager,
    SignInManager<ApplicationUser> signInManager, ApplicationDbContext context) : Controller
{
    [HttpGet] public IActionResult Login(string? returnUrl) => View(new LoginViewModel { ReturnUrl=returnUrl });

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Login(LoginViewModel model)
    {
        if (!ModelState.IsValid) return View(model);
        var result = await signInManager.PasswordSignInAsync(model.Email, model.Password, model.RememberMe, false);
        if (result.Succeeded)
        {
            var user = await userManager.FindByEmailAsync(model.Email);
            if (user is not null && await userManager.IsInRoleAsync(user, "Admin"))
                return RedirectToAction("Index", "Dashboard", new { area="Admin" });
            return LocalRedirect(model.ReturnUrl ?? "/");
        }
        ModelState.AddModelError("", "Email hoặc mật khẩu không đúng.");
        return View(model);
    }

    [HttpGet] public IActionResult Register() => View(new RegisterViewModel());

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Register(RegisterViewModel model)
    {
        if (!ModelState.IsValid) return View(model);
        var user = new ApplicationUser { UserName=model.Email, Email=model.Email, FullName=model.FullName, PhoneNumber=model.Phone };
        var result = await userManager.CreateAsync(user, model.Password);
        if (result.Succeeded)
        {
            await userManager.AddToRoleAsync(user, "Customer");
            context.Customers.Add(new Customer { FullName=model.FullName, Phone=model.Phone, Email=model.Email, ApplicationUserId=user.Id });
            await context.SaveChangesAsync();
            await signInManager.SignInAsync(user, false);
            return RedirectToAction("Index", "Home");
        }
        foreach (var error in result.Errors) ModelState.AddModelError("", error.Description);
        return View(model);
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Logout() { await signInManager.SignOutAsync(); return RedirectToAction("Index", "Home"); }

    [Authorize]
    public async Task<IActionResult> Profile()
    {
        var user = await userManager.GetUserAsync(User);
        var orders = await context.Orders.Include(x => x.OrderDetails)
            .Where(x => x.Customer.ApplicationUserId == user!.Id)
            .OrderByDescending(x => x.CreatedAt).ToListAsync();
        return View(orders);
    }

    [Authorize]
    public async Task<IActionResult> TrackOrder(string? code)
    {
        if (string.IsNullOrWhiteSpace(code)) return View();
        var user = await userManager.GetUserAsync(User);
        var order = await context.Orders.Include(x => x.OrderDetails)
            .FirstOrDefaultAsync(x => x.OrderCode == code && x.Customer.ApplicationUserId == user!.Id);
        if (order is null) ViewBag.Error = "Không tìm thấy đơn hàng phù hợp.";
        return View(order);
    }

    public IActionResult AccessDenied() => View();
}
