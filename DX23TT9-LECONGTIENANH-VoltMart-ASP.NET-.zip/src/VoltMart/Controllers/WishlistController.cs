using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using VoltMart.Data;
using VoltMart.Models;

namespace VoltMart.Controllers;

[Authorize]
public class WishlistController(ApplicationDbContext context, UserManager<ApplicationUser> userManager) : Controller
{
    public async Task<IActionResult> Index()
    {
        var userId = userManager.GetUserId(User);
        var items = await context.Wishlists.Include(x => x.Product).ThenInclude(x => x.Category)
            .Where(x => x.Customer.ApplicationUserId == userId).ToListAsync();
        return View(items);
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Toggle(int productId)
    {
        var userId = userManager.GetUserId(User);
        var customer = await context.Customers.FirstAsync(x => x.ApplicationUserId == userId);
        var item = await context.Wishlists.IgnoreQueryFilters().FirstOrDefaultAsync(x => x.CustomerId == customer.Id && x.ProductId == productId);
        bool added;
        if (item is null) { context.Wishlists.Add(new Wishlist { CustomerId=customer.Id, ProductId=productId }); added=true; }
        else if (!item.IsActive) { item.IsActive=true; added=true; }
        else { item.IsActive=false; added=false; }
        await context.SaveChangesAsync();
        if (Request.Headers["X-Requested-With"] == "XMLHttpRequest") return Json(new { success=true, added });
        return Redirect(Request.Headers["Referer"].ToString());
    }
}
