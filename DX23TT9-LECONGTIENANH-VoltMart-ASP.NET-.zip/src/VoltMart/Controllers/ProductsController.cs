using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using VoltMart.Data;
using VoltMart.Services;

namespace VoltMart.Controllers;

public class ProductsController(IProductService productService, ApplicationDbContext context) : Controller
{
    public async Task<IActionResult> Index(string? q, int? categoryId, int? brandId,
        decimal? minPrice, decimal? maxPrice, string sort = "newest", int page = 1) =>
        View(await productService.SearchAsync(q, categoryId, brandId, minPrice, maxPrice, sort, page));

    public async Task<IActionResult> Details(string slug)
    {
        var product = await productService.GetBySlugAsync(slug);
        if (product is null) return NotFound();
        ViewBag.Related = await context.Products.Include(x => x.Category)
            .Where(x => x.CategoryId == product.CategoryId && x.Id != product.Id)
            .OrderByDescending(x => x.SoldCount).Take(4).ToListAsync();
        return View(product);
    }

    [HttpGet]
    public async Task<IActionResult> Suggestions(string q)
    {
        if (string.IsNullOrWhiteSpace(q)) return Json(Array.Empty<object>());
        var items = await context.Products.Where(x => x.Name.Contains(q) || x.Sku.Contains(q))
            .OrderByDescending(x => x.SoldCount).Take(6)
            .Select(x => new { x.Name, x.Slug, x.Price, x.ThumbnailUrl }).ToListAsync();
        return Json(items);
    }
}
