using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using VoltMart.Data;

namespace VoltMart.Controllers;

public class NewsController(ApplicationDbContext context) : Controller
{
    public async Task<IActionResult> Index() => View(await context.News.Where(x => x.PublishedAt <= DateTime.Now)
        .OrderByDescending(x => x.PublishedAt).ToListAsync());
    public async Task<IActionResult> Details(string slug)
    {
        var article = await context.News.FirstOrDefaultAsync(x => x.Slug == slug);
        if (article is null) return NotFound();
        article.ViewCount++;
        await context.SaveChangesAsync();
        return View(article);
    }
}
