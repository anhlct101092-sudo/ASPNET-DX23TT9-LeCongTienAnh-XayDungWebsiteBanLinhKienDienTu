using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using VoltMart.Data;
using VoltMart.Models;

namespace VoltMart.Controllers;

public class HomeController(ApplicationDbContext context) : Controller
{
    public async Task<IActionResult> Index() => View(new HomeViewModel
    {
        Categories = await context.Categories.OrderBy(x => x.DisplayOrder).Take(10).ToListAsync(),
        Banners = await context.Banners.OrderBy(x => x.DisplayOrder).ToListAsync(),
        FeaturedProducts = await context.Products.Include(x => x.Category).Where(x => x.IsFeatured).OrderByDescending(x => x.SoldCount).Take(6).ToListAsync(),
        NewProducts = await context.Products.Include(x => x.Category).Where(x => x.IsNew).OrderByDescending(x => x.CreatedAt).Take(6).ToListAsync(),
        News = await context.News.Where(x => x.PublishedAt <= DateTime.Now).OrderByDescending(x => x.PublishedAt).Take(3).ToListAsync()
    });

    public IActionResult About() => View();
    public IActionResult Guide() => View();
    public IActionResult Error() => View();
}
