using Microsoft.AspNetCore.Mvc;
using VoltMart.Data;
using VoltMart.Models;

namespace VoltMart.Controllers;

public class ContactController(ApplicationDbContext context) : Controller
{
    [HttpGet] public IActionResult Index() => View(new Contact());
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Index(Contact model)
    {
        ModelState.Remove(nameof(Contact.Id));
        if (!ModelState.IsValid) return View(model);
        context.Contacts.Add(model);
        await context.SaveChangesAsync();
        TempData["Success"] = "VoltMart đã nhận được liên hệ và sẽ phản hồi sớm.";
        return RedirectToAction(nameof(Index));
    }
}
