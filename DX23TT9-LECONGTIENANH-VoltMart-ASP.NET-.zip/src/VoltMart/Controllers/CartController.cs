using Microsoft.AspNetCore.Mvc;
using VoltMart.Services;

namespace VoltMart.Controllers;

public class CartController(ICartService cartService) : Controller
{
    public async Task<IActionResult> Index() => View(await cartService.GetAsync());

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Add(int productId, int quantity = 1)
    {
        var result = await cartService.AddAsync(productId, quantity);
        var cart = await cartService.GetAsync();
        if (Request.Headers["X-Requested-With"] == "XMLHttpRequest")
            return Json(new { result.Success, result.Message, count = cart.Count, subtotal = cart.Subtotal });
        TempData[result.Success ? "Success" : "Error"] = result.Message;
        return Redirect(Request.Headers["Referer"].ToString());
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Update(int productId, int quantity)
    {
        await cartService.UpdateAsync(productId, quantity);
        return RedirectToAction(nameof(Index));
    }

    [HttpPost, ValidateAntiForgeryToken]
    public IActionResult Remove(int productId)
    {
        cartService.Remove(productId);
        return RedirectToAction(nameof(Index));
    }

    [HttpGet]
    public async Task<IActionResult> Summary()
    {
        var cart = await cartService.GetAsync();
        return Json(new { cart.Count, cart.Subtotal });
    }
}
