using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using VoltMart.Data;

namespace VoltMart.Areas.Admin.Controllers;

[Area("Admin"),Authorize(Roles="Admin")]
public class CustomersController(ApplicationDbContext context):Controller
{
    public async Task<IActionResult> Index(string? q)
    {
        var data=context.Customers.Include(x=>x.Orders).AsQueryable();
        if(!string.IsNullOrWhiteSpace(q))data=data.Where(x=>x.FullName.Contains(q)||x.Phone.Contains(q)||(x.Email??"").Contains(q));
        return View(await data.OrderByDescending(x=>x.CreatedAt).ToListAsync());
    }
}
