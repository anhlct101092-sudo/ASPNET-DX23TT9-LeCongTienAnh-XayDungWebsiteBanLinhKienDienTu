using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using VoltMart.Data;
using VoltMart.Models;

namespace VoltMart.Areas.Admin.Controllers;

[Area("Admin"), Authorize(Roles = "Admin")]
public class OrdersController(ApplicationDbContext context) : Controller
{
    public async Task<IActionResult> Index(OrderStatus? status, string? q)
    {
        var orders=context.Orders.Include(x=>x.Customer).Include(x=>x.OrderDetails).AsQueryable();
        if(status.HasValue)orders=orders.Where(x=>x.Status==status);
        if(!string.IsNullOrWhiteSpace(q))orders=orders.Where(x=>x.OrderCode.Contains(q)||x.ReceiverName.Contains(q)||x.ReceiverPhone.Contains(q));
        ViewBag.Status=status;ViewBag.Query=q;
        return View(await orders.OrderByDescending(x=>x.CreatedAt).ToListAsync());
    }
    public async Task<IActionResult> Details(int id)
    {
        var order=await context.Orders.Include(x=>x.Customer).Include(x=>x.OrderDetails).ThenInclude(x=>x.Product).FirstOrDefaultAsync(x=>x.Id==id);
        return order is null?NotFound():View(order);
    }
    [HttpPost,ValidateAntiForgeryToken]
    public async Task<IActionResult> UpdateStatus(int id,OrderStatus status,PaymentStatus paymentStatus)
    {
        var order=await context.Orders.FindAsync(id);if(order is null)return NotFound();
        order.Status=status;order.PaymentStatus=paymentStatus;
        context.AuditLogs.Add(new AuditLog{UserId=User.Identity?.Name,Action="UpdateStatus",EntityName="Order",EntityId=id.ToString(),Detail=$"{status} / {paymentStatus}"});
        await context.SaveChangesAsync();TempData["Success"]="Đã cập nhật trạng thái đơn hàng.";
        return RedirectToAction(nameof(Details),new{id});
    }
}
