using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using VoltMart.Data;
using VoltMart.Models;

namespace VoltMart.Areas.Admin.Controllers;

[Area("Admin"), Authorize(Roles = "Admin")]
public class DashboardController(ApplicationDbContext context) : Controller
{
    public async Task<IActionResult> Index()
    {
        var now = DateTime.Now;
        var start = new DateTime(now.Year, now.Month, 1).AddMonths(-5);
        var completedOrders = await context.Orders.AsNoTracking()
            .Where(x => x.Status != OrderStatus.Cancelled).ToListAsync();
        var byMonth = completedOrders.Where(x => x.CreatedAt >= start)
            .GroupBy(x => new { x.CreatedAt.Year, x.CreatedAt.Month })
            .Select(g => new { g.Key.Year, g.Key.Month, Value=g.Sum(x => x.TotalAmount) }).ToList();
        var top = await context.OrderDetails.Where(x => x.Order.Status != OrderStatus.Cancelled)
            .GroupBy(x => x.ProductName).Select(g => new { Label=g.Key, Quantity=g.Sum(x => x.Quantity) })
            .OrderByDescending(x => x.Quantity).Take(6).ToListAsync();

        return View(new DashboardViewModel
        {
            Revenue=completedOrders.Sum(x => x.TotalAmount),
            OrderCount=await context.Orders.CountAsync(),
            CustomerCount=await context.Customers.CountAsync(),
            ProductCount=await context.Products.CountAsync(),
            LowStockCount=await context.Products.CountAsync(x => x.StockQuantity <= 10),
            RecentOrders=await context.Orders.Include(x => x.Customer).OrderByDescending(x => x.CreatedAt).Take(8).ToListAsync(),
            RevenueByMonth=Enumerable.Range(0,6).Select(offset =>
            {
                var d=start.AddMonths(offset);
                return new ChartPoint($"T{d.Month}/{d.Year}", byMonth.FirstOrDefault(x => x.Year==d.Year && x.Month==d.Month)?.Value ?? 0);
            }).ToList(),
            TopProducts=top.Select(x => new ChartPoint(x.Label,x.Quantity)).ToList()
        });
    }
}
