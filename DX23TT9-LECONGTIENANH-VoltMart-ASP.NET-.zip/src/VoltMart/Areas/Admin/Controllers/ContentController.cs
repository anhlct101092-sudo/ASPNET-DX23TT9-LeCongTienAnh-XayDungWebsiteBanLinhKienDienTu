using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using VoltMart.Data;
using VoltMart.Models;

namespace VoltMart.Areas.Admin.Controllers;

[Area("Admin"), Authorize(Roles="Admin")]
public class ContentController(ApplicationDbContext context) : Controller
{
    public async Task<IActionResult> News()=>View(await context.News.OrderByDescending(x=>x.CreatedAt).ToListAsync());
    [HttpPost,ValidateAntiForgeryToken]
    public async Task<IActionResult> SaveNews(News model)
    {
        if(ModelState.IsValid){if(model.Id==0)context.News.Add(model);else{var e=await context.News.FindAsync(model.Id);if(e is null)return NotFound();context.Entry(e).CurrentValues.SetValues(model);}await context.SaveChangesAsync();TempData["Success"]="Đã lưu tin tức.";}
        return RedirectToAction(nameof(News));
    }
    public async Task<IActionResult> Banners()=>View(await context.Banners.OrderBy(x=>x.DisplayOrder).ToListAsync());
    [HttpPost,ValidateAntiForgeryToken]
    public async Task<IActionResult> SaveBanner(Banner model)
    {
        if(ModelState.IsValid){if(model.Id==0)context.Banners.Add(model);else{var e=await context.Banners.FindAsync(model.Id);if(e is null)return NotFound();context.Entry(e).CurrentValues.SetValues(model);}await context.SaveChangesAsync();TempData["Success"]="Đã lưu banner.";}
        return RedirectToAction(nameof(Banners));
    }
    public async Task<IActionResult> Promotions()=>View(await context.Promotions.OrderByDescending(x=>x.CreatedAt).ToListAsync());
    [HttpPost,ValidateAntiForgeryToken]
    public async Task<IActionResult> SavePromotion(Promotion model)
    {
        if(ModelState.IsValid){model.Code=model.Code.ToUpper();if(model.Id==0)context.Promotions.Add(model);else{var e=await context.Promotions.FindAsync(model.Id);if(e is null)return NotFound();context.Entry(e).CurrentValues.SetValues(model);}await context.SaveChangesAsync();TempData["Success"]="Đã lưu khuyến mãi.";}
        return RedirectToAction(nameof(Promotions));
    }
    public async Task<IActionResult> Contacts()=>View(await context.Contacts.OrderByDescending(x=>x.CreatedAt).ToListAsync());
}
