using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using VoltMart.Data;
using VoltMart.Models;

namespace VoltMart.Areas.Admin.Controllers;

[Area("Admin"), Authorize(Roles = "Admin")]
public class CatalogController(ApplicationDbContext context) : Controller
{
    public async Task<IActionResult> Categories() => View("Categories", await context.Categories.OrderBy(x=>x.DisplayOrder).ToListAsync());
    [HttpPost,ValidateAntiForgeryToken]
    public async Task<IActionResult> SaveCategory(Category model)
    {
        ModelState.Remove(nameof(Category.Products));ModelState.Remove(nameof(Category.Children));
        if(await context.Categories.IgnoreQueryFilters().AnyAsync(x=>x.Slug==model.Slug&&x.Id!=model.Id))ModelState.AddModelError("","Slug đã tồn tại.");
        if(ModelState.IsValid)
        {
            if(model.Id==0)context.Categories.Add(model);else{var e=await context.Categories.FindAsync(model.Id);if(e is null)return NotFound();context.Entry(e).CurrentValues.SetValues(model);}
            await context.SaveChangesAsync();TempData["Success"]="Đã lưu danh mục.";
        } else TempData["Error"]=string.Join(" ",ModelState.Values.SelectMany(x=>x.Errors).Select(x=>x.ErrorMessage));
        return RedirectToAction(nameof(Categories));
    }
    public async Task<IActionResult> Brands() => View("Brands", await context.Brands.OrderBy(x=>x.Name).ToListAsync());
    [HttpPost,ValidateAntiForgeryToken]
    public async Task<IActionResult> SaveBrand(Brand model)
    {
        ModelState.Remove(nameof(Brand.Products));
        if(ModelState.IsValid){if(model.Id==0)context.Brands.Add(model);else{var e=await context.Brands.FindAsync(model.Id);if(e is null)return NotFound();context.Entry(e).CurrentValues.SetValues(model);}await context.SaveChangesAsync();TempData["Success"]="Đã lưu thương hiệu.";}
        return RedirectToAction(nameof(Brands));
    }
    public async Task<IActionResult> Suppliers() => View("Suppliers", await context.Suppliers.OrderBy(x=>x.Name).ToListAsync());
    [HttpPost,ValidateAntiForgeryToken]
    public async Task<IActionResult> SaveSupplier(Supplier model)
    {
        ModelState.Remove(nameof(Supplier.Products));
        if(ModelState.IsValid){if(model.Id==0)context.Suppliers.Add(model);else{var e=await context.Suppliers.FindAsync(model.Id);if(e is null)return NotFound();context.Entry(e).CurrentValues.SetValues(model);}await context.SaveChangesAsync();TempData["Success"]="Đã lưu nhà cung cấp.";}
        return RedirectToAction(nameof(Suppliers));
    }
}
