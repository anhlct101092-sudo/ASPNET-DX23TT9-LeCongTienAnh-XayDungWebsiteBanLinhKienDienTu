using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using VoltMart.Data;
using VoltMart.Models;
using VoltMart.Services;

namespace VoltMart.Areas.Admin.Controllers;

[Area("Admin"), Authorize(Roles = "Admin")]
public class ProductsController(ApplicationDbContext context, IFileService fileService) : Controller
{
    public async Task<IActionResult> Index(string? q, int page = 1)
    {
        var query = context.Products.Include(x => x.Category).Include(x => x.Brand).AsQueryable();
        if (!string.IsNullOrWhiteSpace(q)) query=query.Where(x => x.Name.Contains(q) || x.Sku.Contains(q));
        ViewBag.Query=q; ViewBag.Page=page; ViewBag.TotalPages=(int)Math.Ceiling(await query.CountAsync()/10d);
        return View(await query.OrderByDescending(x => x.CreatedAt).Skip((page-1)*10).Take(10).ToListAsync());
    }

    public async Task<IActionResult> Create() { await LoadOptions(); return View("Form", new Product()); }
    public async Task<IActionResult> Edit(int id)
    {
        var product=await context.Products.Include(x => x.Images).FirstOrDefaultAsync(x => x.Id==id);
        if(product is null)return NotFound(); await LoadOptions(); return View("Form",product);
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Save(Product product, IFormFile? thumbnail, List<IFormFile>? gallery)
    {
        var isNew = product.Id == 0;
        ModelState.Remove(nameof(Product.Category)); ModelState.Remove(nameof(Product.Brand)); ModelState.Remove(nameof(Product.Supplier));
        if (await context.Products.IgnoreQueryFilters().AnyAsync(x => x.Sku == product.Sku && x.Id != product.Id))
            ModelState.AddModelError(nameof(Product.Sku),"Mã SKU đã tồn tại.");
        if (await context.Products.IgnoreQueryFilters().AnyAsync(x => x.Slug == product.Slug && x.Id != product.Id))
            ModelState.AddModelError(nameof(Product.Slug),"Đường dẫn đã tồn tại.");
        if (!ModelState.IsValid) { await LoadOptions(); return View("Form",product); }

        Product entity;
        if (product.Id == 0) { entity=product; context.Products.Add(entity); }
        else
        {
            entity=await context.Products.Include(x => x.Images).FirstAsync(x => x.Id==product.Id);
            context.Entry(entity).CurrentValues.SetValues(product);
        }
        if(thumbnail is not null) entity.ThumbnailUrl=await fileService.SaveImageAsync(thumbnail,"products");
        if(gallery is not null)
            foreach(var file in gallery.Where(x=>x.Length>0))
                entity.Images.Add(new ProductImage { ImageUrl=await fileService.SaveImageAsync(file,"products"), AltText=entity.Name });
        await context.SaveChangesAsync();
        await Log(isNew?"Create":"Update","Product",entity.Id.ToString(),entity.Name);
        TempData["Success"]="Đã lưu sản phẩm.";
        return RedirectToAction(nameof(Index));
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Delete(int id)
    {
        var product=await context.Products.FindAsync(id);
        if(product is null)return NotFound();
        if(await context.OrderDetails.AnyAsync(x=>x.ProductId==id))
        {
            TempData["Error"]="Sản phẩm đã phát sinh đơn hàng nên chỉ có thể ngừng kinh doanh.";
            product.IsActive=false;
        }
        else context.Products.Remove(product);
        await context.SaveChangesAsync(); await Log("Delete","Product",id.ToString(),product.Name);
        return RedirectToAction(nameof(Index));
    }

    private async Task LoadOptions()
    {
        ViewBag.Categories=new SelectList(await context.Categories.OrderBy(x=>x.Name).ToListAsync(),"Id","Name");
        ViewBag.Brands=new SelectList(await context.Brands.OrderBy(x=>x.Name).ToListAsync(),"Id","Name");
        ViewBag.Suppliers=new SelectList(await context.Suppliers.OrderBy(x=>x.Name).ToListAsync(),"Id","Name");
    }
    private async Task Log(string action,string entity,string id,string detail)
    {
        context.AuditLogs.Add(new AuditLog { UserId=User.Identity?.Name,Action=action,EntityName=entity,EntityId=id,Detail=detail,IpAddress=HttpContext.Connection.RemoteIpAddress?.ToString() });
        await context.SaveChangesAsync();
    }
}
