using Microsoft.EntityFrameworkCore;
using VoltMart.Data;
using VoltMart.Models;

namespace VoltMart.Services;

public interface IProductService
{
    Task<ProductListViewModel> SearchAsync(string? query, int? categoryId, int? brandId,
        decimal? minPrice, decimal? maxPrice, string sort, int page, int pageSize = 12);
    Task<Product?> GetBySlugAsync(string slug);
}

public class ProductService(ApplicationDbContext context) : IProductService
{
    public async Task<ProductListViewModel> SearchAsync(string? query, int? categoryId, int? brandId,
        decimal? minPrice, decimal? maxPrice, string sort, int page, int pageSize = 12)
    {
        var products = context.Products.Include(x => x.Category).Include(x => x.Brand).AsNoTracking();
        if (!string.IsNullOrWhiteSpace(query))
        {
            query = query.Trim();
            products = products.Where(x => x.Name.Contains(query) || x.Sku.Contains(query)
                || x.Brand.Name.Contains(query) || x.Category.Name.Contains(query));
        }
        if (categoryId.HasValue) products = products.Where(x => x.CategoryId == categoryId);
        if (brandId.HasValue) products = products.Where(x => x.BrandId == brandId);
        if (minPrice.HasValue) products = products.Where(x => x.Price >= minPrice);
        if (maxPrice.HasValue) products = products.Where(x => x.Price <= maxPrice);

        page = Math.Max(1, page);
        var total = await products.CountAsync();
        List<Product> pageItems;
        if (context.Database.IsSqlite() && sort is "price-asc" or "price-desc")
        {
            var allItems = await products.ToListAsync();
            var sortedItems = sort == "price-asc"
                ? allItems.OrderBy(x => x.Price)
                : allItems.OrderByDescending(x => x.Price);
            pageItems = sortedItems.Skip((page - 1) * pageSize).Take(pageSize).ToList();
        }
        else
        {
            products = sort switch
            {
                "price-asc" => products.OrderBy(x => x.Price),
                "price-desc" => products.OrderByDescending(x => x.Price),
                "popular" => products.OrderByDescending(x => x.SoldCount),
                "name" => products.OrderBy(x => x.Name),
                _ => products.OrderByDescending(x => x.CreatedAt)
            };
            pageItems = await products.Skip((page - 1) * pageSize).Take(pageSize).ToListAsync();
        }
        return new ProductListViewModel
        {
            Products = pageItems,
            Categories = await context.Categories.OrderBy(x => x.DisplayOrder).ToListAsync(),
            Brands = await context.Brands.OrderBy(x => x.Name).ToListAsync(),
            Query=query, CategoryId=categoryId, BrandId=brandId, MinPrice=minPrice, MaxPrice=maxPrice,
            Sort=sort, Page=page, TotalItems=total, TotalPages=(int)Math.Ceiling(total/(double)pageSize)
        };
    }

    public async Task<Product?> GetBySlugAsync(string slug)
    {
        var product = await context.Products.Include(x => x.Category).Include(x => x.Brand)
            .Include(x => x.Images).Include(x => x.Reviews).ThenInclude(x => x.Customer)
            .FirstOrDefaultAsync(x => x.Slug == slug);
        if (product is not null)
        {
            product.ViewCount++;
            await context.SaveChangesAsync();
        }
        return product;
    }
}
