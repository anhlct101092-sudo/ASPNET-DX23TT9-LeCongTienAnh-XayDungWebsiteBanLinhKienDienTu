using System.Text.Json;
using Microsoft.EntityFrameworkCore;
using VoltMart.Data;
using VoltMart.Models;

namespace VoltMart.Services;

public interface ICartService
{
    Task<CartViewModel> GetAsync();
    Task<(bool Success, string Message)> AddAsync(int productId, int quantity);
    Task UpdateAsync(int productId, int quantity);
    void Remove(int productId);
    void Clear();
}

public class CartService(IHttpContextAccessor accessor, ApplicationDbContext context) : ICartService
{
    private const string Key = "VoltMart.Cart";
    private ISession Session => accessor.HttpContext!.Session;
    private Dictionary<int, int> Read() =>
        JsonSerializer.Deserialize<Dictionary<int, int>>(Session.GetString(Key) ?? "{}") ?? [];
    private void Write(Dictionary<int, int> cart) => Session.SetString(Key, JsonSerializer.Serialize(cart));

    public async Task<CartViewModel> GetAsync()
    {
        var cart = Read();
        var ids = cart.Keys.ToList();
        var products = await context.Products.Where(x => ids.Contains(x.Id)).ToListAsync();
        return new CartViewModel
        {
            Items = products.Select(p => new CartItemViewModel
            {
                ProductId=p.Id, ProductName=p.Name, Slug=p.Slug, ThumbnailUrl=p.ThumbnailUrl,
                UnitPrice=p.Price, Quantity=cart[p.Id], StockQuantity=p.StockQuantity
            }).ToList()
        };
    }

    public async Task<(bool Success, string Message)> AddAsync(int productId, int quantity)
    {
        var product = await context.Products.FindAsync(productId);
        if (product is null) return (false, "Sản phẩm không tồn tại.");
        var cart = Read();
        var newQuantity = cart.GetValueOrDefault(productId) + Math.Max(1, quantity);
        if (newQuantity > product.StockQuantity) return (false, $"Kho chỉ còn {product.StockQuantity} sản phẩm.");
        cart[productId] = newQuantity;
        Write(cart);
        return (true, $"Đã thêm {product.Name} vào giỏ hàng.");
    }

    public async Task UpdateAsync(int productId, int quantity)
    {
        var product = await context.Products.FindAsync(productId);
        var cart = Read();
        if (product is null || quantity <= 0) cart.Remove(productId);
        else cart[productId] = Math.Min(quantity, product.StockQuantity);
        Write(cart);
    }
    public void Remove(int productId) { var cart=Read(); cart.Remove(productId); Write(cart); }
    public void Clear() => Session.Remove(Key);
}
