using Microsoft.EntityFrameworkCore;
using VoltMart.Data;

namespace VoltMart.Services;

public interface IRepository<T> where T : class
{
    IQueryable<T> Query();
    Task<T?> GetByIdAsync(int id);
    Task AddAsync(T entity);
    void Update(T entity);
    void Remove(T entity);
    Task<int> SaveChangesAsync();
}

public class Repository<T>(ApplicationDbContext context) : IRepository<T> where T : class
{
    private readonly DbSet<T> _set = context.Set<T>();
    public IQueryable<T> Query() => _set.AsQueryable();
    public Task<T?> GetByIdAsync(int id) => _set.FindAsync(id).AsTask();
    public Task AddAsync(T entity) => _set.AddAsync(entity).AsTask();
    public void Update(T entity) => _set.Update(entity);
    public void Remove(T entity) => _set.Remove(entity);
    public Task<int> SaveChangesAsync() => context.SaveChangesAsync();
}
