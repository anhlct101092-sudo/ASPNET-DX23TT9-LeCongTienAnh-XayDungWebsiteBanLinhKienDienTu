namespace VoltMart.Services;

public interface IFileService
{
    Task<string> SaveImageAsync(IFormFile file, string folder);
    void Delete(string? relativePath);
}

public class FileService(IWebHostEnvironment environment) : IFileService
{
    private static readonly string[] Allowed = [".jpg", ".jpeg", ".png", ".webp", ".gif"];
    public async Task<string> SaveImageAsync(IFormFile file, string folder)
    {
        if (file.Length == 0 || file.Length > 5 * 1024 * 1024) throw new InvalidOperationException("Ảnh tối đa 5 MB.");
        var ext = Path.GetExtension(file.FileName).ToLowerInvariant();
        if (!Allowed.Contains(ext)) throw new InvalidOperationException("Chỉ chấp nhận JPG, PNG, WEBP hoặc GIF.");
        var safeFolder = folder.Trim('/', '\\');
        var directory = Path.Combine(environment.WebRootPath, "uploads", safeFolder);
        Directory.CreateDirectory(directory);
        var fileName = $"{Guid.NewGuid():N}{ext}";
        await using var stream = File.Create(Path.Combine(directory, fileName));
        await file.CopyToAsync(stream);
        return $"/uploads/{safeFolder}/{fileName}";
    }
    public void Delete(string? relativePath)
    {
        if (string.IsNullOrWhiteSpace(relativePath) || !relativePath.StartsWith("/uploads/")) return;
        var path = Path.GetFullPath(Path.Combine(environment.WebRootPath, relativePath.TrimStart('/').Replace('/', Path.DirectorySeparatorChar)));
        if (path.StartsWith(Path.GetFullPath(environment.WebRootPath)) && File.Exists(path)) File.Delete(path);
    }
}
