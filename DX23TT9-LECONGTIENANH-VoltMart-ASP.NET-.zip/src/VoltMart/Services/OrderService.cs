using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using VoltMart.Data;
using VoltMart.Models;

namespace VoltMart.Services;

public interface IOrderService
{
    Task<(Order? Order, string? Error)> CreateAsync(CheckoutViewModel model, ApplicationUser? user);
}

public class OrderService(ApplicationDbContext context, ICartService cartService) : IOrderService
{
    public async Task<(Order? Order, string? Error)> CreateAsync(CheckoutViewModel model, ApplicationUser? user)
    {
        var cart = await cartService.GetAsync();
        if (cart.Items.Count == 0) return (null, "Giỏ hàng đang trống.");
        await using var transaction = await context.Database.BeginTransactionAsync();
        foreach (var item in cart.Items)
        {
            var product = await context.Products.FirstAsync(x => x.Id == item.ProductId);
            if (product.StockQuantity < item.Quantity)
                return (null, $"{product.Name} chỉ còn {product.StockQuantity} sản phẩm.");
            product.StockQuantity -= item.Quantity;
            product.SoldCount += item.Quantity;
        }

        Customer? customer = null;
        if (user is not null)
            customer = await context.Customers.FirstOrDefaultAsync(x => x.ApplicationUserId == user.Id);
        customer ??= new Customer
        {
            FullName=model.ReceiverName, Phone=model.ReceiverPhone,
            Address=model.ShippingAddress, Email=user?.Email, ApplicationUserId=user?.Id
        };
        if (customer.Id == 0) context.Customers.Add(customer);

        decimal discount = 0;
        Promotion? promotion = null;
        if (!string.IsNullOrWhiteSpace(model.PromotionCode))
        {
            var code = model.PromotionCode.Trim().ToUpper();
            promotion = await context.Promotions.FirstOrDefaultAsync(x => x.Code == code
                && x.StartsAt <= DateTime.Now && x.EndsAt >= DateTime.Now
                && (x.UsageLimit == 0 || x.UsedCount < x.UsageLimit));
            if (promotion is not null && cart.Subtotal >= promotion.MinimumOrder)
            {
                discount = promotion.Type == PromotionType.Percent
                    ? cart.Subtotal * promotion.Value / 100 : promotion.Value;
                if (promotion.MaximumDiscount.HasValue) discount = Math.Min(discount, promotion.MaximumDiscount.Value);
                promotion.UsedCount++;
            }
        }
        var shipping = cart.Subtotal >= 500000 ? 0 : 30000;
        var order = new Order
        {
            OrderCode=$"VM{DateTime.Now:yyMMddHHmmss}{Random.Shared.Next(100,999)}", Customer=customer,
            ReceiverName=model.ReceiverName, ReceiverPhone=model.ReceiverPhone,
            ShippingAddress=model.ShippingAddress, Note=model.Note, PaymentMethod=model.PaymentMethod,
            Subtotal=cart.Subtotal, ShippingFee=shipping, DiscountAmount=discount,
            TotalAmount=cart.Subtotal+shipping-discount, PromotionCode=promotion?.Code,
            OrderDetails=cart.Items.Select(x => new OrderDetail
            {
                ProductId=x.ProductId, ProductName=x.ProductName, UnitPrice=x.UnitPrice,
                Quantity=x.Quantity, LineTotal=x.LineTotal
            }).ToList()
        };
        context.Orders.Add(order);
        await context.SaveChangesAsync();
        await transaction.CommitAsync();
        cartService.Clear();
        return (order, null);
    }
}
