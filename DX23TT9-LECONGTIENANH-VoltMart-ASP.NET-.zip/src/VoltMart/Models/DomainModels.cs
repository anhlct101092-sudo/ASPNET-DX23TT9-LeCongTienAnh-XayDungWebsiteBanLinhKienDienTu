using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.AspNetCore.Identity;

namespace VoltMart.Models;

public abstract class BaseEntity
{
    public int Id { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.Now;
    public DateTime? UpdatedAt { get; set; }
    public bool IsActive { get; set; } = true;
}

public class ApplicationUser : IdentityUser
{
    [MaxLength(100)] public string FullName { get; set; } = "";
    [MaxLength(250)] public string? Address { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.Now;
}

public class Category : BaseEntity
{
    [Required, MaxLength(120)] public string Name { get; set; } = "";
    [Required, MaxLength(140)] public string Slug { get; set; } = "";
    [MaxLength(60)] public string? Icon { get; set; }
    public int DisplayOrder { get; set; }
    public int? ParentId { get; set; }
    public Category? Parent { get; set; }
    public ICollection<Category> Children { get; set; } = new List<Category>();
    public ICollection<Product> Products { get; set; } = new List<Product>();
}

public class Brand : BaseEntity
{
    [Required, MaxLength(100)] public string Name { get; set; } = "";
    [Required, MaxLength(120)] public string Slug { get; set; } = "";
    [MaxLength(300)] public string? LogoUrl { get; set; }
    public ICollection<Product> Products { get; set; } = new List<Product>();
}

public class Supplier : BaseEntity
{
    [Required, MaxLength(150)] public string Name { get; set; } = "";
    [MaxLength(20)] public string? Phone { get; set; }
    [EmailAddress, MaxLength(150)] public string? Email { get; set; }
    [MaxLength(250)] public string? Address { get; set; }
    [MaxLength(500)] public string? Note { get; set; }
    public ICollection<Product> Products { get; set; } = new List<Product>();
}

public class Product : BaseEntity
{
    [Required, MaxLength(40)] public string Sku { get; set; } = "";
    [Required, MaxLength(180)] public string Name { get; set; } = "";
    [Required, MaxLength(200)] public string Slug { get; set; } = "";
    [Column(TypeName = "decimal(18,2)"), Range(1, double.MaxValue)] public decimal Price { get; set; }
    [Column(TypeName = "decimal(18,2)")] public decimal? ComparePrice { get; set; }
    [Column(TypeName = "decimal(18,2)")] public decimal CostPrice { get; set; }
    [Range(0, int.MaxValue)] public int StockQuantity { get; set; }
    [MaxLength(40)] public string Unit { get; set; } = "Cái";
    [MaxLength(300)] public string? ThumbnailUrl { get; set; }
    [MaxLength(500)] public string ShortDescription { get; set; } = "";
    public string Description { get; set; } = "";
    public string Specifications { get; set; } = "";
    public bool IsFeatured { get; set; }
    public bool IsNew { get; set; }
    public int ViewCount { get; set; }
    public int SoldCount { get; set; }
    [Range(0, 100)] public int DiscountPercent { get; set; }
    public int CategoryId { get; set; }
    public Category Category { get; set; } = null!;
    public int BrandId { get; set; }
    public Brand Brand { get; set; } = null!;
    public int SupplierId { get; set; }
    public Supplier Supplier { get; set; } = null!;
    public ICollection<ProductImage> Images { get; set; } = new List<ProductImage>();
    public ICollection<OrderDetail> OrderDetails { get; set; } = new List<OrderDetail>();
    public ICollection<Review> Reviews { get; set; } = new List<Review>();
}

public class ProductImage : BaseEntity
{
    [Required, MaxLength(300)] public string ImageUrl { get; set; } = "";
    [MaxLength(180)] public string? AltText { get; set; }
    public bool IsPrimary { get; set; }
    public int DisplayOrder { get; set; }
    public int ProductId { get; set; }
    public Product Product { get; set; } = null!;
}

public class Customer : BaseEntity
{
    [Required, MaxLength(100)] public string FullName { get; set; } = "";
    [Required, MaxLength(20)] public string Phone { get; set; } = "";
    [EmailAddress, MaxLength(150)] public string? Email { get; set; }
    [MaxLength(250)] public string? Address { get; set; }
    public string? ApplicationUserId { get; set; }
    public ApplicationUser? ApplicationUser { get; set; }
    public ICollection<Order> Orders { get; set; } = new List<Order>();
}

public class Employee : BaseEntity
{
    [Required, MaxLength(100)] public string FullName { get; set; } = "";
    [MaxLength(60)] public string Position { get; set; } = "Nhân viên";
    [MaxLength(20)] public string? Phone { get; set; }
    public string? ApplicationUserId { get; set; }
    public ApplicationUser? ApplicationUser { get; set; }
}

public enum OrderStatus { Pending, Confirmed, Shipping, Completed, Cancelled }
public enum PaymentStatus { Unpaid, Paid, Refunded }

public class Order : BaseEntity
{
    [Required, MaxLength(30)] public string OrderCode { get; set; } = "";
    [Required, MaxLength(100)] public string ReceiverName { get; set; } = "";
    [Required, MaxLength(20)] public string ReceiverPhone { get; set; } = "";
    [Required, MaxLength(300)] public string ShippingAddress { get; set; } = "";
    [MaxLength(500)] public string? Note { get; set; }
    [MaxLength(40)] public string PaymentMethod { get; set; } = "COD";
    public OrderStatus Status { get; set; } = OrderStatus.Pending;
    public PaymentStatus PaymentStatus { get; set; } = PaymentStatus.Unpaid;
    [Column(TypeName = "decimal(18,2)")] public decimal Subtotal { get; set; }
    [Column(TypeName = "decimal(18,2)")] public decimal ShippingFee { get; set; }
    [Column(TypeName = "decimal(18,2)")] public decimal DiscountAmount { get; set; }
    [Column(TypeName = "decimal(18,2)")] public decimal TotalAmount { get; set; }
    [MaxLength(50)] public string? PromotionCode { get; set; }
    public int CustomerId { get; set; }
    public Customer Customer { get; set; } = null!;
    public ICollection<OrderDetail> OrderDetails { get; set; } = new List<OrderDetail>();
}

public class OrderDetail : BaseEntity
{
    public int OrderId { get; set; }
    public Order Order { get; set; } = null!;
    public int ProductId { get; set; }
    public Product Product { get; set; } = null!;
    [Required, MaxLength(180)] public string ProductName { get; set; } = "";
    [Column(TypeName = "decimal(18,2)")] public decimal UnitPrice { get; set; }
    [Range(1, int.MaxValue)] public int Quantity { get; set; }
    [Column(TypeName = "decimal(18,2)")] public decimal LineTotal { get; set; }
}

public class Review : BaseEntity
{
    [Range(1, 5)] public int Rating { get; set; }
    [Required, MaxLength(1000)] public string Content { get; set; } = "";
    public bool IsApproved { get; set; }
    public int ProductId { get; set; }
    public Product Product { get; set; } = null!;
    public int CustomerId { get; set; }
    public Customer Customer { get; set; } = null!;
}

public enum PromotionType { Percent, FixedAmount }
public class Promotion : BaseEntity
{
    [Required, MaxLength(50)] public string Code { get; set; } = "";
    [Required, MaxLength(150)] public string Name { get; set; } = "";
    public PromotionType Type { get; set; }
    [Column(TypeName = "decimal(18,2)")] public decimal Value { get; set; }
    [Column(TypeName = "decimal(18,2)")] public decimal MinimumOrder { get; set; }
    [Column(TypeName = "decimal(18,2)")] public decimal? MaximumDiscount { get; set; }
    public int UsageLimit { get; set; }
    public int UsedCount { get; set; }
    public DateTime StartsAt { get; set; }
    public DateTime EndsAt { get; set; }
}

public class News : BaseEntity
{
    [Required, MaxLength(200)] public string Title { get; set; } = "";
    [Required, MaxLength(220)] public string Slug { get; set; } = "";
    [MaxLength(500)] public string Summary { get; set; } = "";
    public string Content { get; set; } = "";
    [MaxLength(300)] public string? ThumbnailUrl { get; set; }
    [MaxLength(100)] public string Author { get; set; } = "VoltMart";
    public DateTime? PublishedAt { get; set; }
    public int ViewCount { get; set; }
}

public class Banner : BaseEntity
{
    [Required, MaxLength(150)] public string Title { get; set; } = "";
    [MaxLength(300)] public string? Subtitle { get; set; }
    [Required, MaxLength(300)] public string ImageUrl { get; set; } = "";
    [MaxLength(300)] public string? LinkUrl { get; set; }
    [MaxLength(50)] public string Position { get; set; } = "HomeHero";
    public int DisplayOrder { get; set; }
    public DateTime? StartsAt { get; set; }
    public DateTime? EndsAt { get; set; }
}

public class Contact : BaseEntity
{
    [Required, MaxLength(100)] public string FullName { get; set; } = "";
    [Required, EmailAddress, MaxLength(150)] public string Email { get; set; } = "";
    [MaxLength(20)] public string? Phone { get; set; }
    [Required, MaxLength(180)] public string Subject { get; set; } = "";
    [Required, MaxLength(2000)] public string Message { get; set; } = "";
    public bool IsRead { get; set; }
    [MaxLength(2000)] public string? Reply { get; set; }
}

public class Wishlist : BaseEntity
{
    public int CustomerId { get; set; }
    public Customer Customer { get; set; } = null!;
    public int ProductId { get; set; }
    public Product Product { get; set; } = null!;
}

public class AuditLog
{
    public long Id { get; set; }
    [MaxLength(450)] public string? UserId { get; set; }
    [Required, MaxLength(100)] public string Action { get; set; } = "";
    [Required, MaxLength(100)] public string EntityName { get; set; } = "";
    [MaxLength(100)] public string? EntityId { get; set; }
    public string? Detail { get; set; }
    [MaxLength(50)] public string? IpAddress { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.Now;
}
