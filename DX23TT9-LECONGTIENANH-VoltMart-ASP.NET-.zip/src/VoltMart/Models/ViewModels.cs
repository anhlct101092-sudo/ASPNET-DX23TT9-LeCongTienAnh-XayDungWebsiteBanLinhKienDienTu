using System.ComponentModel.DataAnnotations;

namespace VoltMart.Models;

public class HomeViewModel
{
    public IReadOnlyList<Category> Categories { get; set; } = [];
    public IReadOnlyList<Banner> Banners { get; set; } = [];
    public IReadOnlyList<Product> FeaturedProducts { get; set; } = [];
    public IReadOnlyList<Product> NewProducts { get; set; } = [];
    public IReadOnlyList<News> News { get; set; } = [];
}

public class ProductListViewModel
{
    public IReadOnlyList<Product> Products { get; set; } = [];
    public IReadOnlyList<Category> Categories { get; set; } = [];
    public IReadOnlyList<Brand> Brands { get; set; } = [];
    public string? Query { get; set; }
    public int? CategoryId { get; set; }
    public int? BrandId { get; set; }
    public decimal? MinPrice { get; set; }
    public decimal? MaxPrice { get; set; }
    public string Sort { get; set; } = "newest";
    public int Page { get; set; } = 1;
    public int TotalPages { get; set; } = 1;
    public int TotalItems { get; set; }
}

public class CartItemViewModel
{
    public int ProductId { get; set; }
    public string ProductName { get; set; } = "";
    public string Slug { get; set; } = "";
    public string? ThumbnailUrl { get; set; }
    public decimal UnitPrice { get; set; }
    public int Quantity { get; set; }
    public int StockQuantity { get; set; }
    public decimal LineTotal => UnitPrice * Quantity;
}

public class CartViewModel
{
    public List<CartItemViewModel> Items { get; set; } = [];
    public decimal Subtotal => Items.Sum(x => x.LineTotal);
    public int Count => Items.Sum(x => x.Quantity);
}

public class CheckoutViewModel
{
    [Required(ErrorMessage = "Vui lòng nhập họ tên")]
    [Display(Name = "Họ và tên")]
    public string ReceiverName { get; set; } = "";

    [Required(ErrorMessage = "Vui lòng nhập số điện thoại")]
    [Phone, Display(Name = "Số điện thoại")]
    public string ReceiverPhone { get; set; } = "";

    [Required(ErrorMessage = "Vui lòng nhập địa chỉ")]
    [Display(Name = "Địa chỉ giao hàng")]
    public string ShippingAddress { get; set; } = "";

    [Display(Name = "Ghi chú")]
    public string? Note { get; set; }

    [Display(Name = "Phương thức thanh toán")]
    public string PaymentMethod { get; set; } = "COD";

    [Display(Name = "Mã giảm giá")]
    public string? PromotionCode { get; set; }
    public CartViewModel Cart { get; set; } = new();
    public decimal ShippingFee { get; set; }
    public decimal DiscountAmount { get; set; }
    public decimal Total => Cart.Subtotal + ShippingFee - DiscountAmount;
}

public class LoginViewModel
{
    [Required, EmailAddress] public string Email { get; set; } = "";
    [Required, DataType(DataType.Password)] public string Password { get; set; } = "";
    [Display(Name = "Ghi nhớ đăng nhập")] public bool RememberMe { get; set; }
    public string? ReturnUrl { get; set; }
}

public class RegisterViewModel
{
    [Required, Display(Name = "Họ và tên")] public string FullName { get; set; } = "";
    [Required, EmailAddress] public string Email { get; set; } = "";
    [Required, Phone, Display(Name = "Số điện thoại")] public string Phone { get; set; } = "";
    [Required, MinLength(6), DataType(DataType.Password)] public string Password { get; set; } = "";
    [Required, Compare(nameof(Password)), DataType(DataType.Password), Display(Name = "Nhập lại mật khẩu")]
    public string ConfirmPassword { get; set; } = "";
}

public class DashboardViewModel
{
    public decimal Revenue { get; set; }
    public int OrderCount { get; set; }
    public int CustomerCount { get; set; }
    public int ProductCount { get; set; }
    public int LowStockCount { get; set; }
    public IReadOnlyList<Order> RecentOrders { get; set; } = [];
    public IReadOnlyList<ChartPoint> RevenueByMonth { get; set; } = [];
    public IReadOnlyList<ChartPoint> TopProducts { get; set; } = [];
}

public record ChartPoint(string Label, decimal Value);
