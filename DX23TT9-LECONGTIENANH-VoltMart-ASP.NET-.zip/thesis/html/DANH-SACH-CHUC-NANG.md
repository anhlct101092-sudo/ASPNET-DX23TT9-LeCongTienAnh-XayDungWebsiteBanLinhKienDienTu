# Danh sách chức năng nghiệm thu

## Khách hàng

- [x] Trang chủ theo giao diện tham khảo.
- [x] Danh mục và danh sách sản phẩm.
- [x] Chi tiết sản phẩm, nhiều ảnh và sản phẩm liên quan.
- [x] Tìm kiếm gợi ý AJAX.
- [x] Lọc thương hiệu, danh mục, khoảng giá.
- [x] Sắp xếp và phân trang.
- [x] Giỏ hàng Session.
- [x] Checkout transaction và mã giảm giá.
- [x] Đăng ký, đăng nhập Identity.
- [x] Phân quyền Admin/Customer.
- [x] Wishlist.
- [x] Lịch sử và theo dõi đơn.
- [x] Tin tức, hướng dẫn và liên hệ.

## Quản trị

- [x] AdminLTE Dashboard.
- [x] Chart.js doanh thu và sản phẩm bán chạy.
- [x] CRUD sản phẩm.
- [x] Upload ảnh đại diện và nhiều ảnh.
- [x] Danh mục, thương hiệu, nhà cung cấp.
- [x] Khách hàng và đơn hàng.
- [x] Tin tức, banner, khuyến mãi, liên hệ.
- [x] Tìm kiếm, lọc và phân trang.
- [x] Audit log.

## Việc nghiệm thu trên máy phát triển

- [x] Chạy restore/build - 0 lỗi, 0 cảnh báo.
- [x] Tạo migration `InitialCreate`.
- [x] Sinh script SQL Server `setup/VoltMartDb.sql`.
- [x] Chạy database phát triển SQLite và seed dữ liệu.
- [x] Chạy các test case chính trong `TEST-REPORT.md`.
- [ ] Nghiệm thu lại trên SQL Server/LocalDB của máy nộp đồ án.
