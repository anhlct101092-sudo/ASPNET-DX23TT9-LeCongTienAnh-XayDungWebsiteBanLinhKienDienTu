# Hồ sơ phân tích và thiết kế hệ thống VoltMart

## 1. Bài toán

VoltMart là hệ thống bán linh kiện điện tử trực tuyến. Khách hàng cần tìm đúng sản phẩm theo tên, mã SKU, danh mục, thương hiệu và mức giá; đặt hàng trong giới hạn tồn kho; theo dõi đơn và lưu sản phẩm yêu thích. Quản trị viên cần quản lý toàn bộ danh mục, nhà cung cấp, hàng hóa, đơn hàng, khách hàng, nội dung quảng bá và số liệu kinh doanh.

## 2. Kiến trúc

```mermaid
flowchart LR
    B[Browser] --> C[ASP.NET Core MVC Controllers]
    C --> S[Service Layer]
    S --> R[Repository / EF Core]
    R --> D[(SQL Server)]
    C --> I[ASP.NET Identity]
    C --> V[Razor Views]
    V --> J[jQuery AJAX / Bootstrap]
```

- Presentation: Razor Views, Bootstrap 5, AdminLTE.
- Application: Controller và Service.
- Data access: Repository và Entity Framework Core.
- Database: SQL Server.
- Security: ASP.NET Core Identity và Role.

## 3. Tác nhân

### Khách vãng lai

- Xem, tìm kiếm và lọc sản phẩm.
- Xem chi tiết, tin tức và hướng dẫn.
- Thêm giỏ và đặt hàng không bắt buộc đăng nhập.
- Đăng ký, đăng nhập.

### Khách hàng

- Toàn bộ chức năng khách vãng lai.
- Wishlist.
- Lịch sử và theo dõi đơn hàng.

### Quản trị viên

- Dashboard thống kê.
- CRUD dữ liệu hệ thống.
- Upload nhiều ảnh.
- Xử lý đơn và thanh toán.
- Quản lý khách hàng, nội dung, banner, khuyến mãi và liên hệ.

## 4. Mô hình dữ liệu chính

```mermaid
erDiagram
    CATEGORY ||--o{ PRODUCT : contains
    BRAND ||--o{ PRODUCT : brands
    SUPPLIER ||--o{ PRODUCT : supplies
    PRODUCT ||--o{ PRODUCT_IMAGE : has
    PRODUCT ||--o{ ORDER_DETAIL : ordered
    ORDER ||--|{ ORDER_DETAIL : contains
    CUSTOMER ||--o{ ORDER : places
    CUSTOMER ||--o{ REVIEW : writes
    PRODUCT ||--o{ REVIEW : receives
    CUSTOMER ||--o{ WISHLIST : owns
    PRODUCT ||--o{ WISHLIST : saved
    APPLICATION_USER ||--o| CUSTOMER : maps
    APPLICATION_USER ||--o| EMPLOYEE : maps
```

## 5. Danh mục bảng

| Bảng | Mục đích |
|---|---|
| Category | Danh mục phân cấp |
| Brand | Thương hiệu |
| Supplier | Nhà cung cấp |
| Product | Sản phẩm, giá, tồn kho |
| ProductImage | Nhiều ảnh sản phẩm |
| Customer | Hồ sơ khách hàng |
| Employee | Hồ sơ nhân viên |
| Order | Thông tin đơn và thanh toán |
| OrderDetail | Sản phẩm thuộc đơn |
| Review | Đánh giá sản phẩm |
| Promotion | Mã giảm giá |
| News | Tin tức |
| Banner | Banner quảng cáo |
| Contact | Liên hệ khách hàng |
| Wishlist | Sản phẩm yêu thích |
| AuditLog | Nhật ký quản trị |

## 6. Ràng buộc toàn vẹn

- SKU, slug sản phẩm, slug danh mục, slug thương hiệu, mã đơn, mã giảm giá là duy nhất.
- Giá bán lớn hơn 0; giá dùng kiểu `decimal(18,2)`.
- Tồn kho và số lượng mua không âm; số lượng đặt không vượt tồn kho.
- Wishlist có khóa duy nhất `(CustomerId, ProductId)`.
- Không xóa vật lý sản phẩm đã phát sinh đơn; chuyển `IsActive=false`.
- Đặt hàng thực hiện trong database transaction.
- Mã giảm giá kiểm tra thời hạn, số lần dùng, giá trị đơn tối thiểu và mức giảm tối đa.
- Email tài khoản Identity là duy nhất.

## 7. Luồng đặt hàng

```mermaid
flowchart TD
    A[Thêm sản phẩm vào giỏ Session] --> B{Đủ tồn kho?}
    B -->|Không| C[Thông báo giới hạn]
    B -->|Có| D[Nhập thông tin giao hàng]
    D --> E[Kiểm tra mã giảm giá]
    E --> F[Begin SQL Transaction]
    F --> G[Kiểm tra lại và trừ tồn kho]
    G --> H[Tạo Customer nếu cần]
    H --> I[Tạo Order và OrderDetail]
    I --> J[Commit Transaction]
    J --> K[Xóa Session Cart]
```

## 8. Bảo mật

- Identity hash mật khẩu và quản lý cookie xác thực.
- `[Authorize(Roles="Admin")]` bảo vệ toàn bộ Admin Area.
- Anti-forgery token cho form POST.
- Upload giới hạn định dạng và 5 MB.
- EF Core parameter hóa truy vấn, giảm nguy cơ SQL Injection.
- Không lưu mật khẩu hoặc connection string production trong repository.

## 9. Đối chiếu phiếu đánh giá

| Tiêu chí | Minh chứng |
|---|---|
| Giao diện hài hòa | Thiết kế xanh-trắng nhất quán, responsive |
| Menu đúng nghiệp vụ | Header khách hàng và sidebar AdminLTE |
| Lưu trữ hoàn chỉnh | SQL Server + EF Core + Identity |
| CRUD ổn định | Product, Category, Brand, Supplier, News, Banner, Promotion |
| Ràng buộc | Unique indexes, validation, transaction và khóa ngoại |
| Tra cứu | Tìm tên/SKU/danh mục/thương hiệu |
| Tìm kiếm tương đối | SQL `Contains` và AJAX suggestions |
| Thống kê | Dashboard doanh thu, top sản phẩm, tồn kho |
