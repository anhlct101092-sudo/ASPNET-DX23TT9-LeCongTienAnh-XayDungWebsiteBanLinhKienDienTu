# Tài liệu tham khảo

[1] Microsoft, “ASP.NET Core documentation,” Microsoft Learn, 2026.

[2] Mozilla Developer Network, “HTML, CSS and JavaScript Web APIs,” MDN Web Docs, 2026.

[3] E. Freeman and E. Robson, *Head First Design Patterns*, 2nd ed., O’Reilly Media, 2020.

[4] M. Fowler, *Patterns of Enterprise Application Architecture*, Addison-Wesley, 2002.
